# NameUse - iHRIS Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NameUse**

## CodeSystem: NameUse 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://hl7.org/fhir/name-use | *Version*:0.1.0 | |
| * Standards status: *[Normative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 5 | *Computable Name*:NameUse |
| *Other Identifiers:*OID:2.16.840.1.113883.4.642.1.66 | | |

 
The use of a human name. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [NameUse](ValueSet-name-use.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "name-use",
  "meta" : {
    "lastUpdated" : "2022-06-14T13:46:01.394+00:00"
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
    "valueCode" : "fhir"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "normative"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
    "valueCode" : "4.0.0"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 5
  }],
  "url" : "http://hl7.org/fhir/name-use",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.16.840.1.113883.4.642.1.66"
  }],
  "version" : "0.1.0",
  "name" : "NameUse",
  "title" : "NameUse",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-09T12:31:23+00:00",
  "publisher" : "Luke Duncan",
  "contact" : [{
    "name" : "Luke Duncan",
    "telecom" : [{
      "system" : "email",
      "value" : "lduncan@intrahealth.org"
    }]
  }],
  "description" : "The use of a human name.",
  "caseSensitive" : true,
  "valueSet" : "http://hl7.org/fhir/ValueSet/name-use",
  "content" : "complete",
  "count" : 7,
  "concept" : [{
    "code" : "usual",
    "display" : "Usual",
    "definition" : "Known as/conventional/the one you normally use."
  },
  {
    "code" : "official",
    "display" : "Official",
    "definition" : "The formal name as registered in an official (government) registry, but which name might not be commonly used. May be called \"legal name\"."
  },
  {
    "code" : "temp",
    "display" : "Temp",
    "definition" : "A temporary name. Name.period can provide more detailed information. This may also be used for temporary names assigned at birth or in emergency situations."
  },
  {
    "code" : "nickname",
    "display" : "Nickname",
    "definition" : "A name that is used to address the person in an informal manner, but is not part of their formal or usual name."
  },
  {
    "code" : "anonymous",
    "display" : "Anonymous",
    "definition" : "Anonymous assigned name, alias, or pseudonym (used to protect a person's identity for privacy reasons)."
  },
  {
    "code" : "old",
    "display" : "Old",
    "definition" : "This name is no longer in use (or was never correct, but retained for records).",
    "concept" : [{
      "code" : "maiden",
      "display" : "Name changed for Marriage",
      "definition" : "A name used prior to changing name because of marriage. This name use is for use by applications that collect and store names that were used prior to a marriage. Marriage naming customs vary greatly around the world, and are constantly changing. This term is not gender specific. The use of this term does not imply any particular history for a person's name."
    }]
  }]
}

```
