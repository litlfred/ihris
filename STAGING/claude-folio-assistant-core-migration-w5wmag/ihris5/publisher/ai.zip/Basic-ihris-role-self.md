# iHRIS Self Service Role - iHRIS Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **iHRIS Self Service Role**

## Example Basic: iHRIS Self Service Role

Profile: [iHRIS Role](StructureDefinition-ihris-role.md)

**iHRIS Basic Name**: Self Service Role

**iHRIS Role Primary**: false

**iHRIS Assign Task**: [Basic iHRIS Task](Basic-ihris-task-read-questionnaire-resource.md)

**iHRIS Assign Task**: [Basic iHRIS Task](Basic-ihris-task-navigation-profile.md)

**iHRIS Assign Task**: [Basic iHRIS Task](Basic-ihris-task-navigation-leave.md)

**iHRIS Assign Task**: [Basic iHRIS Task](Basic-ihris-task-navigation-password.md)

**iHRIS Assign Task**: [Basic iHRIS Task](Basic-ihris-task-read-ihris-page-practitioner.md)

**iHRIS Assign Task**: [Basic iHRIS Task](Basic-ihris-task-read-ihris-page-practitioner-role.md)

**iHRIS Assign Task**: [Basic iHRIS Task](Basic-ihris-task-read-code-system.md)

**iHRIS Assign Task**: [Basic iHRIS Task](Basic-ihris-task-read-value-set.md)

**iHRIS Assign Task**: [Basic iHRIS Task](Basic-ihris-task-read-location-resource.md)

**iHRIS Assign Task**: [Basic iHRIS Task](Basic-ihris-task-read-practitioner-resource.md)

**iHRIS Assign Task**: [Basic iHRIS Task](Basic-ihris-task-read-practitioner-role-resource.md)

**iHRIS Assign Task**: [Basic iHRIS Task](Basic-ihris-task-write-practitioner-resource.md)

**iHRIS Assign Task**: [Basic iHRIS Task](Basic-ihris-task-read-questionnaire-response-resource.md)

**iHRIS Assign Task**: [Basic iHRIS Task](Basic-ihris-task-read-basic-resource.md)

**iHRIS Assign Task**: [Basic iHRIS Task](Basic-ihris-task-write-questionnaire-response-resource.md)

**iHRIS Assign Task**: [Basic iHRIS Task](Basic-ihris-task-write-questionnaire-resource.md)

**iHRIS Assign Task**: [Basic iHRIS Task](Basic-ihris-task-read-questionnaire-leave.md)

**iHRIS Assign Task**: [Basic iHRIS Task](Basic-ihris-task-write-questionnaire-leave.md)

**iHRIS Assign Task**: [Basic iHRIS Task](Basic-ihris-task-write-basic-resource.md)

**iHRIS Assign Task**: [Basic iHRIS Task](Basic-ihris-task-write-questionnaire-change-password.md)

**iHRIS Assign Task**: [Basic iHRIS Task](Basic-ihris-task-write-person-resource.md)

**code**: iHRIS Role



## Resource Content

```json
{
  "resourceType" : "Basic",
  "id" : "ihris-role-self",
  "meta" : {
    "profile" : ["http://ihris.org/fhir/StructureDefinition/ihris-role"]
  },
  "extension" : [{
    "url" : "http://ihris.org/fhir/StructureDefinition/ihris-basic-name",
    "valueString" : "Self Service Role"
  },
  {
    "url" : "http://ihris.org/fhir/StructureDefinition/ihris-role-primary",
    "valueBoolean" : false
  },
  {
    "url" : "http://ihris.org/fhir/StructureDefinition/ihris-assign-task",
    "valueReference" : {
      "reference" : "Basic/ihris-task-read-questionnaire-resource"
    }
  },
  {
    "url" : "http://ihris.org/fhir/StructureDefinition/ihris-assign-task",
    "valueReference" : {
      "reference" : "Basic/ihris-task-navigation-profile"
    }
  },
  {
    "url" : "http://ihris.org/fhir/StructureDefinition/ihris-assign-task",
    "valueReference" : {
      "reference" : "Basic/ihris-task-navigation-leave"
    }
  },
  {
    "url" : "http://ihris.org/fhir/StructureDefinition/ihris-assign-task",
    "valueReference" : {
      "reference" : "Basic/ihris-task-navigation-password"
    }
  },
  {
    "url" : "http://ihris.org/fhir/StructureDefinition/ihris-assign-task",
    "valueReference" : {
      "reference" : "Basic/ihris-task-read-ihris-page-practitioner"
    }
  },
  {
    "url" : "http://ihris.org/fhir/StructureDefinition/ihris-assign-task",
    "valueReference" : {
      "reference" : "Basic/ihris-task-read-ihris-page-practitioner-role"
    }
  },
  {
    "url" : "http://ihris.org/fhir/StructureDefinition/ihris-assign-task",
    "valueReference" : {
      "reference" : "Basic/ihris-task-read-code-system"
    }
  },
  {
    "url" : "http://ihris.org/fhir/StructureDefinition/ihris-assign-task",
    "valueReference" : {
      "reference" : "Basic/ihris-task-read-value-set"
    }
  },
  {
    "url" : "http://ihris.org/fhir/StructureDefinition/ihris-assign-task",
    "valueReference" : {
      "reference" : "Basic/ihris-task-read-location-resource"
    }
  },
  {
    "url" : "http://ihris.org/fhir/StructureDefinition/ihris-assign-task",
    "valueReference" : {
      "reference" : "Basic/ihris-task-read-practitioner-resource"
    }
  },
  {
    "url" : "http://ihris.org/fhir/StructureDefinition/ihris-assign-task",
    "valueReference" : {
      "reference" : "Basic/ihris-task-read-practitioner-role-resource"
    }
  },
  {
    "url" : "http://ihris.org/fhir/StructureDefinition/ihris-assign-task",
    "valueReference" : {
      "reference" : "Basic/ihris-task-write-practitioner-resource"
    }
  },
  {
    "url" : "http://ihris.org/fhir/StructureDefinition/ihris-assign-task",
    "valueReference" : {
      "reference" : "Basic/ihris-task-read-questionnaire-response-resource"
    }
  },
  {
    "url" : "http://ihris.org/fhir/StructureDefinition/ihris-assign-task",
    "valueReference" : {
      "reference" : "Basic/ihris-task-read-basic-resource"
    }
  },
  {
    "url" : "http://ihris.org/fhir/StructureDefinition/ihris-assign-task",
    "valueReference" : {
      "reference" : "Basic/ihris-task-write-questionnaire-response-resource"
    }
  },
  {
    "url" : "http://ihris.org/fhir/StructureDefinition/ihris-assign-task",
    "valueReference" : {
      "reference" : "Basic/ihris-task-write-questionnaire-resource"
    }
  },
  {
    "url" : "http://ihris.org/fhir/StructureDefinition/ihris-assign-task",
    "valueReference" : {
      "reference" : "Basic/ihris-task-read-questionnaire-leave"
    }
  },
  {
    "url" : "http://ihris.org/fhir/StructureDefinition/ihris-assign-task",
    "valueReference" : {
      "reference" : "Basic/ihris-task-write-questionnaire-leave"
    }
  },
  {
    "url" : "http://ihris.org/fhir/StructureDefinition/ihris-assign-task",
    "valueReference" : {
      "reference" : "Basic/ihris-task-write-basic-resource"
    }
  },
  {
    "url" : "http://ihris.org/fhir/StructureDefinition/ihris-assign-task",
    "valueReference" : {
      "reference" : "Basic/ihris-task-write-questionnaire-change-password"
    }
  },
  {
    "url" : "http://ihris.org/fhir/StructureDefinition/ihris-assign-task",
    "valueReference" : {
      "reference" : "Basic/ihris-task-write-person-resource"
    }
  }],
  "code" : {
    "coding" : [{
      "system" : "http://ihris.org/fhir/CodeSystem/ihris-resource-codesystem",
      "code" : "role"
    }]
  }
}

```
