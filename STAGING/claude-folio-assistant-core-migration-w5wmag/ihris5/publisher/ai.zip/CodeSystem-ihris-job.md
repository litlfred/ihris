# iHRIS Job - iHRIS Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **iHRIS Job**

## CodeSystem: iHRIS Job 

| | |
| :--- | :--- |
| *Official URL*:http://ihris.org/fhir/CodeSystem/ihris-job | *Version*:0.1.0 |
| Active as of 2020-09-25 | *Computable Name*:IhrisJob |

 
Sample iHRIS CodeSystem for: IhrisJob 

 This Code system is referenced in the content logical definition of the following value sets: 

* [iHRIS Job](ValueSet-ihris-job.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "ihris-job",
  "url" : "http://ihris.org/fhir/CodeSystem/ihris-job",
  "version" : "0.1.0",
  "name" : "IhrisJob",
  "title" : "iHRIS Job",
  "status" : "active",
  "date" : "2020-09-25T20:48:33.646Z",
  "publisher" : "Luke Duncan",
  "contact" : [{
    "name" : "Luke Duncan",
    "telecom" : [{
      "system" : "email",
      "value" : "lduncan@intrahealth.org"
    }]
  }],
  "description" : "Sample iHRIS CodeSystem for: IhrisJob",
  "content" : "complete",
  "count" : 51,
  "property" : [{
    "code" : "cadre",
    "uri" : "http://ihris.org/fhir/ValueSet/ihris-cadre",
    "description" : "The cadre of this job.",
    "type" : "Coding"
  },
  {
    "code" : "classification",
    "uri" : "http://ihris.org/fhir/ValueSet/ihris-classification",
    "description" : "The classification of this job.",
    "type" : "Coding"
  },
  {
    "code" : "salary-grade",
    "uri" : "http://ihris.org/fhir/ValueSet/ihris-salary-grade",
    "description" : "The salary grade of this job.",
    "type" : "Coding"
  }],
  "concept" : [{
    "code" : "1231-1C",
    "display" : "Manager",
    "definition" : "Department managers plan, direct and coordinate the internal administration or financial operations of the enterprise or organisation, under the broad guidance of the directors.",
    "property" : [{
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "non-health"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "prof-mid-level"
      }
    }]
  },
  {
    "code" : "1420-A",
    "display" : "Administrative Assistant",
    "property" : [{
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "non-health"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "entry-level"
      }
    }]
  },
  {
    "code" : "2221-1D",
    "display" : "Medical Doctor",
    "definition" : "Medical doctors conduct research, improve or develop concepts, theories and operational methods, and apply preventive or curative measures.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "doctor"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "doctor"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "director"
      }
    }]
  },
  {
    "code" : "2221-2D",
    "display" : "Specialized Doctor",
    "definition" : "Medical doctors conduct research, improve or develop concepts, theories and operational methods, and apply preventive or curative measures.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "doctor"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "doctor"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "director"
      }
    }]
  },
  {
    "code" : "2221-3D",
    "display" : "Opthalmologist",
    "definition" : "Medical doctors conduct research, improve or develop concepts, theories and operational methods, and apply preventive or curative measures.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "doctor"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "doctor"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "director"
      }
    }]
  },
  {
    "code" : "2221-4D",
    "display" : "Orthopedist",
    "definition" : "Lab technicians perform technical tasks connected with the development of medical, public health and other practical applications of research results.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "doctor"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "doctor"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "director"
      }
    }]
  },
  {
    "code" : "2221-5D",
    "display" : "Surgeon",
    "definition" : "Medical doctors conduct research, improve or develop concepts, theories and operational methods, and apply preventive or curative measures.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "doctor"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "doctor"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "director"
      }
    }]
  },
  {
    "code" : "2222-2D",
    "display" : "Dentist",
    "definition" : "Dentists conduct research, improve or develop concepts, theories and operational methods, and apply medical knowledge in the field of dentistry.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "allied-health"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "allied-health"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "director"
      }
    }]
  },
  {
    "code" : "2224-1D",
    "display" : "Pharmacist",
    "definition" : "Pharmacists apply pharmaceutical concepts and theories by preparing and dispensing or selling medicaments and drugs.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "allied-health"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "allied-health"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "director"
      }
    }]
  },
  {
    "code" : "2229-3C",
    "display" : "Epidemiologist",
    "definition" : "Epidemiologists conduct research, improve or develop concepts, theories and operational methods, and apply preventive or curative measures in epidemiology.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "allied-health"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "allied-health"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "prof-mid-level"
      }
    }]
  },
  {
    "code" : "2230-1B",
    "display" : "Nurse",
    "definition" : "Nursing and midwifery professionals assist medical doctors in their tasks, deal with emergencies in their absence, and provide professional nursing care for the sick, injured, physically and mentally disabled, and others in need of such care.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "nurse"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "nurse"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "prof-entry-level"
      }
    }]
  },
  {
    "code" : "2230-1C",
    "display" : "Deputy Chief Nurse",
    "definition" : "Nursing and midwifery professionals assist medical doctors in their tasks, deal with emergencies in their absence, and provide professional nursing care for the sick, injured, physically and mentally disabled, and others in need of such care.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "nurse"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "nurse"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "prof-mid-level"
      }
    }]
  },
  {
    "code" : "2230-1D",
    "display" : "Chief Nurse",
    "definition" : "Nursing and midwifery professionals assist medical doctors in their tasks, deal with emergencies in their absence, and provide professional nursing care for the sick, injured, physically and mentally disabled, and others in need of such care.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "nurse"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "nurse"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "director"
      }
    }]
  },
  {
    "code" : "2230-2B",
    "display" : "Midwife",
    "definition" : "Midwifery professionals deliver or assist in the delivery of babies, provide antenatal and post-natal care and instruct parents in baby care.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "nurse"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "nurse"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "prof-entry-level"
      }
    }]
  },
  {
    "code" : "2411-1B",
    "display" : "Accountant",
    "definition" : "Accountants advise on accounting matters and perform accountancy services or audits.",
    "property" : [{
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "non-health"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "prof-entry-level"
      }
    }]
  },
  {
    "code" : "2432-1B",
    "display" : "Archivist",
    "definition" : "Medical archivists collect and store recorded or published material, and retrieve and provide information as requested.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "allied-health"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "allied-health"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "prof-entry-level"
      }
    }]
  },
  {
    "code" : "2445-1B",
    "display" : "Counselor",
    "property" : [{
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "non-health"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "prof-entry-level"
      }
    }]
  },
  {
    "code" : "2445-1C",
    "display" : "Clinical Psychologist",
    "definition" : "Psychologists research into and study mental processes and behaviour of human beings as individuals or in groups, and apply this knowledge to promote personal, social, educational or occupational adjustment and development.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "allied-health"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "allied-health"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "prof-mid-level"
      }
    }]
  },
  {
    "code" : "2446-1C",
    "display" : "Social Worker",
    "definition" : "Social work professionals provide guidance to clients in social and related matters to enable them to find and use resources to overcome difficulties and achieve particular goals.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "allied-health"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "allied-health"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "prof-mid-level"
      }
    }]
  },
  {
    "code" : "3211-1A",
    "display" : "Technician",
    "definition" : "Lab technicians perform technical tasks connected with the development of medical, public health and other practical applications of research results.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "allied-health"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "allied-health"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "entry-level"
      }
    }]
  },
  {
    "code" : "3211-1C",
    "display" : "Lab Technician",
    "definition" : "Lab technicians perform technical tasks connected with the development of medical, public health and other practical applications of research results.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "allied-health"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "allied-health"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "prof-mid-level"
      }
    }]
  },
  {
    "code" : "3211-2A",
    "display" : "Lab Assistant",
    "definition" : "Lab assistants carry out laboratory tasks, more limited in scope and complexity than those carried out by Lab Technicians.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "allied-health"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "allied-health"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "entry-level"
      }
    }]
  },
  {
    "code" : "3211-3B",
    "display" : "Radiology Technician",
    "definition" : "Radiologist technicians perform technical tasks connected with the development of medical, public health and other practical applications of research results in radiology.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "allied-health"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "allied-health"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "prof-entry-level"
      }
    }]
  },
  {
    "code" : "3211-4B",
    "display" : "Orthopedist Aide",
    "definition" : "Medical assistants carry out advisory, diagnostic, preventive and curative medical tasks, more limited in scope and complexity than those carried out by Medical doctors.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "allied-health"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "allied-health"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "prof-entry-level"
      }
    }]
  },
  {
    "code" : "3221-1C",
    "display" : "Medical Assistant",
    "definition" : "Medical assistants carry out advisory, diagnostic, preventive and curative medical tasks, more limited in scope and complexity than those carried out by Medical doctors.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "allied-health"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "allied-health"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "prof-mid-level"
      }
    }]
  },
  {
    "code" : "3221-2B",
    "display" : "Anesthesiology Assistant",
    "definition" : "Anesthesiologist techs carry out advisory, diagnostic, preventive and curative medical tasks, more limited in scope and complexity than those carried out by Anesthesiologists.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "allied-health"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "allied-health"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "prof-entry-level"
      }
    }]
  },
  {
    "code" : "3222-1A",
    "display" : "Hygienist Aide",
    "definition" : "Sanitarians provide technical assistance and advice on measures to restore or improve sanitary conditions, and supervise their implementation.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "allied-health"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "allied-health"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "entry-level"
      }
    }]
  },
  {
    "code" : "3222-1B",
    "display" : "Hygienist",
    "definition" : "Sanitarians provide technical assistance and advice on measures to restore or improve sanitary conditions, and supervise their implementation.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "allied-health"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "allied-health"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "prof-entry-level"
      }
    }]
  },
  {
    "code" : "3223-1B",
    "display" : "Nutritionist",
    "definition" : "Nutritionists conduct research and improve or develop concepts and operational methods concerning the preparation and application of diets for general and therapeutic purposes.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "allied-health"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "allied-health"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "prof-entry-level"
      }
    }]
  },
  {
    "code" : "3223-1C",
    "display" : "Anesthesiologist",
    "definition" : "Nutritionists conduct research and improve or develop concepts and operational methods concerning the preparation and application of diets for general and therapeutic purposes.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "allied-health"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "allied-health"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "prof-mid-level"
      }
    }]
  },
  {
    "code" : "3223-2A",
    "display" : "Nutritionist Aide",
    "definition" : "Nutritionist Aides assist nutritionists with research, concepts and operational methods concerning the preparation and application of diets for general and therapeutic purposes.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "allied-health"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "allied-health"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "entry-level"
      }
    }]
  },
  {
    "code" : "3225-1B",
    "display" : "Dental Technician",
    "definition" : "Dental technicians carry out advisory, diagnostic, preventive and curative dental tasks, more limited in scope and complexity than those carried out by Dentists.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "allied-health"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "allied-health"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "prof-entry-level"
      }
    }]
  },
  {
    "code" : "3226-1A",
    "display" : "Physiotherapy Aide",
    "definition" : "Physiotherapists and related associate professionals treat disorders of bones, muscles and parts of the circulatory or the nervous system by manipulative methods.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "allied-health"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "allied-health"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "entry-level"
      }
    }]
  },
  {
    "code" : "3226-1B",
    "display" : "Physiotherapist",
    "definition" : "Physiotherapists treat disorders of bones, muscles and parts of the circulatory or the nervous system by manipulative methods, and ultrasound, heating, laser or similar techniques.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "allied-health"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "allied-health"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "prof-entry-level"
      }
    }]
  },
  {
    "code" : "3228-1B",
    "display" : "Pharmacy Technician",
    "definition" : "Pharmaceutical assistants dispense and prepare medicaments, lotions and mixtures under the guidance of Pharmacists, in pharmacies, hospitals and dispensaries.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "allied-health"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "allied-health"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "prof-mid-level"
      }
    }]
  },
  {
    "code" : "3229-3A",
    "display" : "Environmental Health Worker",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "allied-health"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "allied-health"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "entry-level"
      }
    }]
  },
  {
    "code" : "3232-2A",
    "display" : "Nurse Midwife Aid",
    "definition" : "Midwifery assistants deliver or assist doctors or midwifery professionals in the delivery of babies, provide antenatal and post-natal care and instruct parents in baby care.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "nurse"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "nurse"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "entry-level"
      }
    }]
  },
  {
    "code" : "3431-1D",
    "display" : "Administrator",
    "definition" : "Administrators implement and support the communication, documentation and internal managerial co-ordination activities of an organisational unit.",
    "property" : [{
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "non-health"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "director"
      }
    }]
  },
  {
    "code" : "3460-1A",
    "display" : "Social Work Aide",
    "definition" : "Social work aides provide guidance to clients in social and related matters to enable them to find and use resources to overcome difficulties and achieve particular goals.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "allied-health"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "allied-health"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "entry-level"
      }
    }]
  },
  {
    "code" : "4115-1A",
    "display" : "Secretary",
    "definition" : "Secretaries use typewriters or word-processing equipment to check and transcribe correspondence and other documents, deal with incoming and outgoing mail, screen requests for meetings or appointments, record and screen leave and other staff entitlements.",
    "property" : [{
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "support"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "entry-level"
      }
    }]
  },
  {
    "code" : "4211-1A",
    "display" : "Cashier",
    "definition" : "Cashiers receive payments for goods or services.",
    "property" : [{
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "support"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "entry-level"
      }
    }]
  },
  {
    "code" : "4222-1A",
    "display" : "Receptionist",
    "definition" : "Receptionists receive clients or patients, provide information and make appointments on behalf of various establishments including hospitals, medical or dental surgeries.",
    "property" : [{
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "support"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "entry-level"
      }
    }]
  },
  {
    "code" : "5121-2A",
    "display" : "Laundry Staff",
    "definition" : "Laundry staff organise, supervise and carry out laundry functions in medical institutions.",
    "property" : [{
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "support"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "entry-level"
      }
    }]
  },
  {
    "code" : "5132-1A",
    "display" : "Nurse Aide",
    "definition" : "Institution-based Nurse Aides perform simple tasks to assist medical, nursing, midwifery and dental professionals or associate professionals in their duties.",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "nurse"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "nurse"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "entry-level"
      }
    }]
  },
  {
    "code" : "5169-1A",
    "display" : "Guard",
    "definition" : "Guards patrol buildings and areas to prevent illegal entry, theft, violence and other unlawful acts, and, if necessary, use force to prevent such acts and apprehend perpetrators, as well as act as bodyguards.",
    "property" : [{
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "support"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "entry-level"
      }
    }]
  },
  {
    "code" : "6113-1A",
    "display" : "Gardener",
    "definition" : "Gardeners plan and carry out the necessary operations to grow vegetables by intensive cultivation techniques, to cultivate trees, shrubs, flowers and other plants, and to produce saplings, bulbs and seeds.",
    "property" : [{
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "support"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "entry-level"
      }
    }]
  },
  {
    "code" : "7137-1B",
    "display" : "Electrician",
    "definition" : "Building and related electricians install, maintain and repair electrical wiring systems and related equipment.",
    "property" : [{
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "support"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "prof-entry-level"
      }
    }]
  },
  {
    "code" : "7231-1B",
    "display" : "Mechanic",
    "definition" : "Motor vehicle mechanics and fitters fit, install, maintain, service and repair engines and the mechanical and related equipment of motor cycles, passenger cars and delivery trucks and other motor vehicles.",
    "property" : [{
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "support"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "prof-entry-level"
      }
    }]
  },
  {
    "code" : "8322-1A",
    "display" : "Driver",
    "definition" : "Drivers drive and tend motor cars and vans to transport passengers, mail or goods.",
    "property" : [{
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "support"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "entry-level"
      }
    }]
  },
  {
    "code" : "NURS-I",
    "display" : "Nurse I",
    "property" : [{
      "code" : "cadre",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "nurse"
      }
    },
    {
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "nurse"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "prof-entry-level"
      }
    }]
  },
  {
    "code" : "RM-001",
    "display" : "Records Manager",
    "definition" : "Manages medical records.",
    "property" : [{
      "code" : "classification",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-classification",
        "code" : "support"
      }
    },
    {
      "code" : "salary-grade",
      "valueCoding" : {
        "system" : "http://ihris.org/fhir/CodeSystem/ihris-salary-grade",
        "code" : "prof-entry-level"
      }
    }]
  }]
}

```
