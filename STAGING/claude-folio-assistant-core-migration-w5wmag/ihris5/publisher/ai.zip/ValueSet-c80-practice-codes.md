# Practice Setting Code Value Set - iHRIS Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Practice Setting Code Value Set**

## ValueSet: Practice Setting Code Value Set 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://ihris.org/fhir/ValueSet/c80-practice-codes | *Version*:0.1.0 | |
| * Standards status: *[Draft](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:PracticeSettingCodeValueSet |
| *Other Identifiers:*OID:2.16.840.1.113883.3.88.12.80.72 | | |
| **Copyright/Legal**: This resource includes content from SNOMED Clinical Terms® (SNOMED CT®) which is copyright of the International Health Terminology Standards Development Organisation (IHTSDO). Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact http://www.snomed.org/snomed-ct/get-snomed-ct or info@snomed.org | | |

 
This is the code representing the clinical specialty of the clinician or provider who interacted with, treated, or provided a service to/for the patient. The value set used for clinical specialty has been limited by HITSP to the value set reproduced from HITSP C80 Table 2-149 Clinical Specialty Value Set Definition. 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

No Expansion for this valueset (not supported by Publication Tooling)

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "c80-practice-codes",
  "meta" : {
    "versionId" : "1",
    "lastUpdated" : "2022-02-15T08:15:27.072+03:00",
    "source" : "#eMWFzSyStKyyxKMM",
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablevalueset"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
    "valueCode" : "sd"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "draft"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1
  }],
  "url" : "http://ihris.org/fhir/ValueSet/c80-practice-codes",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.16.840.1.113883.3.88.12.80.72"
  }],
  "version" : "0.1.0",
  "name" : "PracticeSettingCodeValueSet",
  "title" : "Practice Setting Code Value Set",
  "status" : "active",
  "experimental" : false,
  "date" : "2019-11-01T09:29:23+11:00",
  "publisher" : "Luke Duncan",
  "contact" : [{
    "name" : "Luke Duncan",
    "telecom" : [{
      "system" : "email",
      "value" : "lduncan@intrahealth.org"
    }]
  }],
  "description" : "This is the code representing the clinical specialty of the clinician or provider who interacted with, treated, or provided a service to/for the patient. The value set used for clinical specialty has been limited by HITSP to the value set reproduced from HITSP C80 Table 2-149 Clinical Specialty Value Set Definition.",
  "copyright" : "This resource includes content from SNOMED Clinical Terms® (SNOMED CT®) which is copyright of the International Health Terminology Standards Development Organisation (IHTSDO). Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact http://www.snomed.org/snomed-ct/get-snomed-ct or info@snomed.org",
  "compose" : {
    "include" : [{
      "system" : "http://snomed.info/sct",
      "concept" : [{
        "code" : "408467006",
        "display" : "Adult mental illness"
      },
      {
        "code" : "394577000",
        "display" : "Anesthetics"
      },
      {
        "code" : "394578005",
        "display" : "Audiological medicine"
      },
      {
        "code" : "421661004",
        "display" : "Blood banking and transfusion medicine"
      },
      {
        "code" : "408462000",
        "display" : "Burns care"
      },
      {
        "code" : "394579002",
        "display" : "Cardiology"
      },
      {
        "code" : "394804000",
        "display" : "Clinical cytogenetics and molecular genetics"
      },
      {
        "code" : "394580004",
        "display" : "Clinical genetics"
      },
      {
        "code" : "394803006",
        "display" : "Clinical hematology"
      },
      {
        "code" : "408480009",
        "display" : "Clinical immunology"
      },
      {
        "code" : "408454008",
        "display" : "Clinical microbiology"
      },
      {
        "code" : "394809005",
        "display" : "Clinical neuro-physiology"
      },
      {
        "code" : "394592004",
        "display" : "Clinical oncology"
      },
      {
        "code" : "394600006",
        "display" : "Clinical pharmacology"
      },
      {
        "code" : "394601005",
        "display" : "Clinical physiology"
      },
      {
        "code" : "394581000",
        "display" : "Community medicine"
      },
      {
        "code" : "408478003",
        "display" : "Critical care medicine"
      },
      {
        "code" : "394812008",
        "display" : "Dental medicine specialties"
      },
      {
        "code" : "408444009",
        "display" : "Dental-General dental practice"
      },
      {
        "code" : "394582007",
        "display" : "Dermatology"
      },
      {
        "code" : "408475000",
        "display" : "Diabetic medicine"
      },
      {
        "code" : "410005002",
        "display" : "Dive medicine"
      },
      {
        "code" : "394583002",
        "display" : "Endocrinology"
      },
      {
        "code" : "419772000",
        "display" : "Family practice"
      },
      {
        "code" : "394584008",
        "display" : "Gastroenterology"
      },
      {
        "code" : "408443003",
        "display" : "General medical practice"
      },
      {
        "code" : "394802001",
        "display" : "General medicine"
      },
      {
        "code" : "394915009",
        "display" : "General pathology"
      },
      {
        "code" : "394814009",
        "display" : "General practice"
      },
      {
        "code" : "394808002",
        "display" : "Genito-urinary medicine"
      },
      {
        "code" : "394811001",
        "display" : "Geriatric medicine"
      },
      {
        "code" : "408446006",
        "display" : "Gynecological oncology"
      },
      {
        "code" : "394586005",
        "display" : "Gynecology"
      },
      {
        "code" : "394916005",
        "display" : "Hematopathology"
      },
      {
        "code" : "408472002",
        "display" : "Hepatology"
      },
      {
        "code" : "394597005",
        "display" : "Histopathology"
      },
      {
        "code" : "394598000",
        "display" : "Immunopathology"
      },
      {
        "code" : "394807007",
        "display" : "Infectious diseases"
      },
      {
        "code" : "419192003",
        "display" : "Internal medicine"
      },
      {
        "code" : "408468001",
        "display" : "Learning disability"
      },
      {
        "code" : "394593009",
        "display" : "Medical oncology"
      },
      {
        "code" : "394813003",
        "display" : "Medical ophthalmology"
      },
      {
        "code" : "410001006",
        "display" : "Military medicine"
      },
      {
        "code" : "394589003",
        "display" : "Nephrology"
      },
      {
        "code" : "394591006",
        "display" : "Neurology"
      },
      {
        "code" : "394599008",
        "display" : "Neuropathology"
      },
      {
        "code" : "394649004",
        "display" : "Nuclear medicine"
      },
      {
        "code" : "408470005",
        "display" : "Obstetrics"
      },
      {
        "code" : "394585009",
        "display" : "Obstetrics and gynecology"
      },
      {
        "code" : "394821009",
        "display" : "Occupational medicine"
      },
      {
        "code" : "422191005",
        "display" : "Ophthalmic surgery"
      },
      {
        "code" : "394594003",
        "display" : "Ophthalmology"
      },
      {
        "code" : "416304004",
        "display" : "Osteopathic manipulative medicine"
      },
      {
        "code" : "418960008",
        "display" : "Otolaryngology"
      },
      {
        "code" : "394882004",
        "display" : "Pain management"
      },
      {
        "code" : "394806003",
        "display" : "Palliative medicine"
      },
      {
        "code" : "394588006",
        "display" : "Pediatric (Child and adolescent) psychiatry"
      },
      {
        "code" : "408459003",
        "display" : "Pediatric cardiology"
      },
      {
        "code" : "394607009",
        "display" : "Pediatric dentistry"
      },
      {
        "code" : "419610006",
        "display" : "Pediatric endocrinology"
      },
      {
        "code" : "418058008",
        "display" : "Pediatric gastroenterology"
      },
      {
        "code" : "420208008",
        "display" : "Pediatric genetics"
      },
      {
        "code" : "418652005",
        "display" : "Pediatric hematology"
      },
      {
        "code" : "418535003",
        "display" : "Pediatric immunology"
      },
      {
        "code" : "418862001",
        "display" : "Pediatric infectious diseases"
      },
      {
        "code" : "419365004",
        "display" : "Pediatric nephrology"
      },
      {
        "code" : "418002000",
        "display" : "Pediatric oncology"
      },
      {
        "code" : "419983000",
        "display" : "Pediatric ophthalmology"
      },
      {
        "code" : "419170002",
        "display" : "Pediatric pulmonology"
      },
      {
        "code" : "419472004",
        "display" : "Pediatric rheumatology"
      },
      {
        "code" : "394539006",
        "display" : "Pediatric surgery"
      },
      {
        "code" : "420112009",
        "display" : "Pediatric surgery-bone marrow transplantation"
      },
      {
        "code" : "409968004",
        "display" : "Preventive medicine"
      },
      {
        "code" : "394587001",
        "display" : "Psychiatry"
      },
      {
        "code" : "394913002",
        "display" : "Psychotherapy"
      },
      {
        "code" : "408440000",
        "display" : "Public health medicine"
      },
      {
        "code" : "418112009",
        "display" : "Pulmonary medicine"
      },
      {
        "code" : "419815003",
        "display" : "Radiation oncology"
      },
      {
        "code" : "394914008",
        "display" : "Radiology"
      },
      {
        "code" : "408455009",
        "display" : "Radiology-Interventional radiology"
      },
      {
        "code" : "394602003",
        "display" : "Rehabilitation"
      },
      {
        "code" : "408447002",
        "display" : "Respite care"
      },
      {
        "code" : "394810000",
        "display" : "Rheumatology"
      },
      {
        "code" : "408450004",
        "display" : "Sleep studies"
      },
      {
        "code" : "408476004",
        "display" : "Surgery-Bone and marrow transplantation"
      },
      {
        "code" : "408469009",
        "display" : "Surgery-Breast surgery"
      },
      {
        "code" : "408466002",
        "display" : "Surgery-Cardiac surgery"
      },
      {
        "code" : "408471009",
        "display" : "Surgery-Cardiothoracic transplantation"
      },
      {
        "code" : "408464004",
        "display" : "Surgery-Colorectal surgery"
      },
      {
        "code" : "408441001",
        "display" : "Surgery-Dental-Endodontics"
      },
      {
        "code" : "408465003",
        "display" : "Surgery-Dental-Oral and maxillofacial surgery"
      },
      {
        "code" : "394605001",
        "display" : "Surgery-Dental-Oral surgery"
      },
      {
        "code" : "394608004",
        "display" : "Surgery-Dental-Orthodontics"
      },
      {
        "code" : "408461007",
        "display" : "Surgery-Dental-Periodontal surgery"
      },
      {
        "code" : "408460008",
        "display" : "Surgery-Dental-Prosthetic Dentistry (Prosthodontics)"
      },
      {
        "code" : "394606000",
        "display" : "Surgery-Dentistry-Restorative dentistry"
      },
      {
        "code" : "408449004",
        "display" : "Surgery-Dentistry-surgical"
      },
      {
        "code" : "418018006",
        "display" : "Surgery-Dermatologic surgery"
      },
      {
        "code" : "394604002",
        "display" : "Surgery-Ear, nose and throat surgery"
      },
      {
        "code" : "394609007",
        "display" : "Surgery-general"
      },
      {
        "code" : "408474001",
        "display" : "Surgery-Hepatobiliary and pancreatic surgery"
      },
      {
        "code" : "394610002",
        "display" : "Surgery-Neurosurgery"
      },
      {
        "code" : "394611003",
        "display" : "Surgery-Plastic surgery"
      },
      {
        "code" : "408477008",
        "display" : "Surgery-Transplantation surgery"
      },
      {
        "code" : "394801008",
        "display" : "Surgery-Trauma and orthopedics"
      },
      {
        "code" : "408463005",
        "display" : "Surgery-Vascular"
      },
      {
        "code" : "419321007",
        "display" : "Surgical oncology"
      },
      {
        "code" : "394576009",
        "display" : "Surgical-Accident & emergency"
      },
      {
        "code" : "394590007",
        "display" : "Thoracic medicine"
      },
      {
        "code" : "409967009",
        "display" : "Toxicology"
      },
      {
        "code" : "408448007",
        "display" : "Tropical medicine"
      },
      {
        "code" : "419043006",
        "display" : "Urological oncology"
      },
      {
        "code" : "394612005",
        "display" : "Urology"
      },
      {
        "code" : "394733009",
        "display" : "Medical specialty--OTHER--NOT LISTED"
      },
      {
        "code" : "394732004",
        "display" : "Surgical specialty--OTHER-NOT LISTED"
      }]
    }]
  }
}

```
