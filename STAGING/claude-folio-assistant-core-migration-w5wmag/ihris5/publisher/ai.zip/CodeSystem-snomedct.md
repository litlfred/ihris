# SNOMED CT (all versions) - iHRIS Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **SNOMED CT (all versions)**

## CodeSystem: SNOMED CT (all versions) 

| | |
| :--- | :--- |
| *Official URL*:http://snomed.info/sct | *Version*:0.1.0 |
| Active as of 2026-10-09 | *Computable Name*:SNOMED_CT |
| *Other Identifiers:*OID:2.16.840.1.113883.6.96 | |
| **Copyright/Legal**: © 2002-2016 International Health Terminology Standards Development Organisation (IHTSDO). All rights reserved. SNOMED CT®, was originally created by The College of American Pathologists. "SNOMED" and "SNOMED CT" are registered trademarks of the IHTSDO http://www.ihtsdo.org/snomed-ct/get-snomed-ct | |

 
SNOMED CT is the most comprehensive and precise clinical health terminology product in the world, owned and distributed around the world by The International Health Terminology Standards Development Organisation (IHTSDO). 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Practice Setting Code Value Set](ValueSet-c80-practice-codes.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "snomedct",
  "meta" : {
    "versionId" : "1",
    "lastUpdated" : "2022-02-15T08:13:52.270+03:00",
    "source" : "#F3FREVVOnY6AuVZY"
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
    "valueCode" : "fhir"
  }],
  "url" : "http://snomed.info/sct",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.16.840.1.113883.6.96"
  }],
  "version" : "0.1.0",
  "name" : "SNOMED_CT",
  "title" : "SNOMED CT (all versions)",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-09T11:54:20+00:00",
  "publisher" : "Luke Duncan",
  "contact" : [{
    "name" : "Luke Duncan",
    "telecom" : [{
      "system" : "email",
      "value" : "lduncan@intrahealth.org"
    }]
  }],
  "description" : "SNOMED CT is the most comprehensive and precise clinical health terminology product in the world, owned and distributed around the world by The International Health Terminology Standards Development Organisation (IHTSDO).",
  "copyright" : "© 2002-2016 International Health Terminology Standards Development Organisation (IHTSDO). All rights reserved. SNOMED CT®, was originally created by The College of American Pathologists. \"SNOMED\" and \"SNOMED CT\" are registered trademarks of the IHTSDO http://www.ihtsdo.org/snomed-ct/get-snomed-ct",
  "caseSensitive" : false,
  "hierarchyMeaning" : "is-a",
  "compositional" : true,
  "versionNeeded" : false,
  "content" : "not-present",
  "filter" : [{
    "code" : "concept",
    "description" : "Filter that includes concepts based on their logical definition. e.g. [concept] [is-a] [x] - include all concepts with an is-a relationship to concept x, or [concept] [in] [x]- include all concepts in the reference set identified by concept x",
    "operator" : ["is-a", "in"],
    "value" : "A SNOMED CT code"
  },
  {
    "code" : "expression",
    "description" : "The result of the filter is the result of executing the given SNOMED CT Expression Constraint",
    "operator" : ["="],
    "value" : "A SNOMED CT ECL expression (see http://snomed.org/ecl)"
  },
  {
    "code" : "expressions",
    "description" : "Whether post-coordinated expressions are included in the value set",
    "operator" : ["="],
    "value" : "true or false"
  }],
  "property" : [{
    "code" : "inactive",
    "uri" : "http://snomed.info/field/Concept.active",
    "description" : "Whether the code is active or not (defaults to false). Not the same as deprecated",
    "type" : "boolean"
  },
  {
    "code" : "definitionStatusId",
    "uri" : "http://snomed.info/field/Concept.definitionStatusId",
    "description" : "Either of the codes that are descendants of 900000000000444006",
    "type" : "code"
  },
  {
    "code" : "parent",
    "uri" : "http://.........?",
    "description" : "A SNOMED CT concept id that has the target of a direct is-a relationship from the concept",
    "type" : "code"
  },
  {
    "code" : "child",
    "uri" : "http://.........?",
    "description" : "A SNOMED CT concept id that has a direct is-a relationship to the concept",
    "type" : "code"
  },
  {
    "code" : "moduleId",
    "uri" : "http://snomed.info/field/Concept.moduleId",
    "description" : "The SNOMED CT concept id of the module that the concept belongs to.",
    "type" : "code"
  },
  {
    "code" : "normalForm",
    "uri" : "http://.........?",
    "description" : "Generated Normal form expression for the provided code or expression, with terms",
    "type" : "string"
  },
  {
    "code" : "normalFormTerse",
    "uri" : "http://.........?",
    "description" : "Generated Normal form expression for the provided code or expression, conceptIds only",
    "type" : "string"
  },
  {
    "code" : "Due to",
    "uri" : "http://snomed.info/id/42752001",
    "type" : "code"
  },
  {
    "code" : "Associated with",
    "uri" : "http://snomed.info/id/47429007",
    "type" : "code"
  },
  {
    "code" : "Associated morphology",
    "uri" : "http://snomed.info/id/116676008",
    "type" : "code"
  },
  {
    "code" : "Has specimen",
    "uri" : "http://snomed.info/id/116686009",
    "type" : "code"
  },
  {
    "code" : "Specimen source morphology",
    "uri" : "http://snomed.info/id/118168003",
    "type" : "code"
  },
  {
    "code" : "Specimen source topography",
    "uri" : "http://snomed.info/id/118169006",
    "type" : "code"
  },
  {
    "code" : "Specimen source identity",
    "uri" : "http://snomed.info/id/118170007",
    "type" : "code"
  },
  {
    "code" : "Specimen procedure",
    "uri" : "http://snomed.info/id/118171006",
    "type" : "code"
  },
  {
    "code" : "Part of",
    "uri" : "http://snomed.info/id/123005000",
    "type" : "code"
  },
  {
    "code" : "Has active ingredient",
    "uri" : "http://snomed.info/id/127489000",
    "type" : "code"
  },
  {
    "code" : "Subject of information",
    "uri" : "http://snomed.info/id/131195008",
    "type" : "code"
  },
  {
    "code" : "Causative agent",
    "uri" : "http://snomed.info/id/246075003",
    "type" : "code"
  },
  {
    "code" : "Associated finding",
    "uri" : "http://snomed.info/id/246090004",
    "type" : "code"
  },
  {
    "code" : "Component",
    "uri" : "http://snomed.info/id/246093002",
    "type" : "code"
  },
  {
    "code" : "Severity",
    "uri" : "http://snomed.info/id/246112005",
    "type" : "code"
  },
  {
    "code" : "Occurrence",
    "uri" : "http://snomed.info/id/246454002",
    "type" : "code"
  },
  {
    "code" : "Episodicity",
    "uri" : "http://snomed.info/id/246456000",
    "type" : "code"
  },
  {
    "code" : "Technique",
    "uri" : "http://snomed.info/id/246501002",
    "type" : "code"
  },
  {
    "code" : "Revision status",
    "uri" : "http://snomed.info/id/246513007",
    "type" : "code"
  },
  {
    "code" : "Units",
    "uri" : "http://snomed.info/id/246514001",
    "type" : "code"
  },
  {
    "code" : "After",
    "uri" : "http://snomed.info/id/255234002",
    "type" : "code"
  },
  {
    "code" : "Access",
    "uri" : "http://snomed.info/id/260507000",
    "type" : "code"
  },
  {
    "code" : "Method",
    "uri" : "http://snomed.info/id/260686004",
    "type" : "code"
  },
  {
    "code" : "Priority",
    "uri" : "http://snomed.info/id/260870009",
    "type" : "code"
  },
  {
    "code" : "Clinical course",
    "uri" : "http://snomed.info/id/263502005",
    "type" : "code"
  },
  {
    "code" : "Laterality",
    "uri" : "http://snomed.info/id/272741003",
    "type" : "code"
  },
  {
    "code" : "Associated procedure",
    "uri" : "http://snomed.info/id/363589002",
    "type" : "code"
  },
  {
    "code" : "Finding site",
    "uri" : "http://snomed.info/id/363698007",
    "type" : "code"
  },
  {
    "code" : "Laterality",
    "uri" : "http://snomed.info/id/363699004",
    "type" : "code"
  },
  {
    "code" : "Direct morphology",
    "uri" : "http://snomed.info/id/363700003",
    "type" : "code"
  },
  {
    "code" : "Direct substance",
    "uri" : "http://snomed.info/id/363701004",
    "type" : "code"
  },
  {
    "code" : "Has focus",
    "uri" : "http://snomed.info/id/363702006",
    "type" : "code"
  },
  {
    "code" : "Has intent",
    "uri" : "http://snomed.info/id/363703001",
    "type" : "code"
  },
  {
    "code" : "Procedure site",
    "uri" : "http://snomed.info/id/363704007",
    "type" : "code"
  },
  {
    "code" : "Has definitional manifestation",
    "uri" : "http://snomed.info/id/363705008",
    "type" : "code"
  },
  {
    "code" : "Indirect morphology",
    "uri" : "http://snomed.info/id/363709002",
    "type" : "code"
  },
  {
    "code" : "Indirect device",
    "uri" : "http://snomed.info/id/363710007",
    "type" : "code"
  },
  {
    "code" : "Has interpretation",
    "uri" : "http://snomed.info/id/363713009",
    "type" : "code"
  },
  {
    "code" : "Interprets",
    "uri" : "http://snomed.info/id/363714003",
    "type" : "code"
  },
  {
    "code" : "Measurement method",
    "uri" : "http://snomed.info/id/370129005",
    "type" : "code"
  },
  {
    "code" : "Property",
    "uri" : "http://snomed.info/id/370130000",
    "type" : "code"
  },
  {
    "code" : "Recipient category",
    "uri" : "http://snomed.info/id/370131001",
    "type" : "code"
  },
  {
    "code" : "Scale type",
    "uri" : "http://snomed.info/id/370132008",
    "type" : "code"
  },
  {
    "code" : "Specimen substance",
    "uri" : "http://snomed.info/id/370133003",
    "type" : "code"
  },
  {
    "code" : "Time aspect",
    "uri" : "http://snomed.info/id/370134009",
    "type" : "code"
  },
  {
    "code" : "Pathological process",
    "uri" : "http://snomed.info/id/370135005",
    "type" : "code"
  },
  {
    "code" : "Procedure site - Direct",
    "uri" : "http://snomed.info/id/405813007",
    "type" : "code"
  },
  {
    "code" : "Procedure site - Indirect",
    "uri" : "http://snomed.info/id/405814001",
    "type" : "code"
  },
  {
    "code" : "Procedure device",
    "uri" : "http://snomed.info/id/405815000",
    "type" : "code"
  },
  {
    "code" : "Procedure morphology",
    "uri" : "http://snomed.info/id/405816004",
    "type" : "code"
  },
  {
    "code" : "Finding context",
    "uri" : "http://snomed.info/id/408729009",
    "type" : "code"
  },
  {
    "code" : "Procedure context",
    "uri" : "http://snomed.info/id/408730004",
    "type" : "code"
  },
  {
    "code" : "Temporal context",
    "uri" : "http://snomed.info/id/408731000",
    "type" : "code"
  },
  {
    "code" : "Subject relationship context",
    "uri" : "http://snomed.info/id/408732007",
    "type" : "code"
  },
  {
    "code" : "Route of administration",
    "uri" : "http://snomed.info/id/410675002",
    "type" : "code"
  },
  {
    "code" : "Has dose form",
    "uri" : "http://snomed.info/id/411116001",
    "type" : "code"
  },
  {
    "code" : "Finding method",
    "uri" : "http://snomed.info/id/418775008",
    "type" : "code"
  },
  {
    "code" : "Finding informer",
    "uri" : "http://snomed.info/id/419066007",
    "type" : "code"
  },
  {
    "code" : "Using device",
    "uri" : "http://snomed.info/id/424226004",
    "type" : "code"
  },
  {
    "code" : "Using energy",
    "uri" : "http://snomed.info/id/424244007",
    "type" : "code"
  },
  {
    "code" : "Using substance",
    "uri" : "http://snomed.info/id/424361007",
    "type" : "code"
  },
  {
    "code" : "Surgical approach",
    "uri" : "http://snomed.info/id/424876005",
    "type" : "code"
  },
  {
    "code" : "Using access device",
    "uri" : "http://snomed.info/id/425391005",
    "type" : "code"
  },
  {
    "code" : "Role group",
    "uri" : "http://snomed.info/id/609096000",
    "type" : "code"
  },
  {
    "code" : "Property type",
    "uri" : "http://snomed.info/id/704318007",
    "type" : "code"
  },
  {
    "code" : "Inheres in",
    "uri" : "http://snomed.info/id/704319004",
    "type" : "code"
  },
  {
    "code" : "Towards",
    "uri" : "http://snomed.info/id/704320005",
    "type" : "code"
  },
  {
    "code" : "Characterizes",
    "uri" : "http://snomed.info/id/704321009",
    "type" : "code"
  },
  {
    "code" : "Process agent",
    "uri" : "http://snomed.info/id/704322002",
    "type" : "code"
  },
  {
    "code" : "Process duration",
    "uri" : "http://snomed.info/id/704323007",
    "type" : "code"
  },
  {
    "code" : "Process output",
    "uri" : "http://snomed.info/id/704324001",
    "type" : "code"
  },
  {
    "code" : "Relative to",
    "uri" : "http://snomed.info/id/704325000",
    "type" : "code"
  },
  {
    "code" : "Precondition",
    "uri" : "http://snomed.info/id/704326004",
    "type" : "code"
  },
  {
    "code" : "Direct site",
    "uri" : "http://snomed.info/id/704327008",
    "type" : "code"
  },
  {
    "code" : "Specified by",
    "uri" : "http://snomed.info/id/704346009",
    "type" : "code"
  },
  {
    "code" : "Observes",
    "uri" : "http://snomed.info/id/704347000",
    "type" : "code"
  },
  {
    "code" : "Is about",
    "uri" : "http://snomed.info/id/704647008",
    "type" : "code"
  }]
}

```
