# Common Languages - iHRIS Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Common Languages**

## ValueSet: Common Languages (Experimental) 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://hl7.org/fhir/ValueSet/languages | *Version*:0.1.0 | |
| * Standards status: *[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 3 | *Computable Name*:CommonLanguages |
| *Other Identifiers:*OID:2.16.840.1.113883.4.642.3.20 | | |

 
This value set includes common codes from BCP-47 (http://tools.ietf.org/html/bcp47) 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

No Expansion for this valueset (Unknown Code System)

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "languages",
  "meta" : {
    "versionId" : "1",
    "lastUpdated" : "2022-02-15T08:15:57.573+03:00",
    "source" : "#CnS3ajMd14M2CL4m",
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablevalueset"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
    "valueCode" : "fhir"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "trial-use"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 3
  }],
  "url" : "http://hl7.org/fhir/ValueSet/languages",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.16.840.1.113883.4.642.3.20"
  }],
  "version" : "0.1.0",
  "name" : "CommonLanguages",
  "title" : "Common Languages",
  "status" : "draft",
  "experimental" : true,
  "date" : "2016-08-22T09:53:05+00:00",
  "publisher" : "Luke Duncan",
  "contact" : [{
    "name" : "Luke Duncan",
    "telecom" : [{
      "system" : "email",
      "value" : "lduncan@intrahealth.org"
    }]
  }],
  "description" : "This value set includes common codes from BCP-47 (http://tools.ietf.org/html/bcp47)",
  "compose" : {
    "include" : [{
      "system" : "urn:ietf:bcp:47",
      "concept" : [{
        "code" : "ar",
        "display" : "Arabic",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Arabisk"
        },
        {
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Arabic"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Arabisch"
        }]
      },
      {
        "code" : "bn",
        "display" : "Bengali",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Bengali"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Bengaals"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Бенгальский"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "孟加拉语"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Bengalisch"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Bengalsk"
        }]
      },
      {
        "code" : "cs",
        "display" : "Czech",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Czech"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Tsjechisch"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Чешский"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "捷克语"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Tschechisch"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Tjekkisk"
        }]
      },
      {
        "code" : "da",
        "display" : "Danish",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Danish"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Deens"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Датский"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "丹麦语"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Dänisch"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Dansk"
        }]
      },
      {
        "code" : "de",
        "display" : "German",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "German"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Duits"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Немецкий"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "德语"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Deutsch"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Tysk"
        }]
      },
      {
        "code" : "de-AT",
        "display" : "German (Austria)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "German (Austria)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Duits (Oostenrijk)"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Немецкий (Австрия)"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "德语 （奥地利）"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Deutsch (Österreich)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Tysk (Østrig"
        }]
      },
      {
        "code" : "de-CH",
        "display" : "German (Switzerland)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "German (Switzerland)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Duits (Zwitserland)"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Немецкий (Швейцария)"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "德语 （瑞士）"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Deutsch (Schweiz)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Tysk (Schweiz)"
        }]
      },
      {
        "code" : "de-DE",
        "display" : "German (Germany)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "German (Germany)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Duits (Duitsland)"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Немецкий (Германия)"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "德语 （德国）"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Deutsch (Deutschland)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Tysk (Tyskland)"
        }]
      },
      {
        "code" : "el",
        "display" : "Greek",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Greek"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Grieks"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Греческий"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "希腊语"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Griechisch"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Græsk"
        }]
      },
      {
        "code" : "en",
        "display" : "English",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "English"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Engels"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Английский"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "英语"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Englisch"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Engelsk"
        }]
      },
      {
        "code" : "en-AU",
        "display" : "English (Australia)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "English (Australia)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Engels (Australië)"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Английский (Австралия)"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "英语 （澳大利亚）"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Englisch (Australien)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Engelsk (Australien)"
        }]
      },
      {
        "code" : "en-CA",
        "display" : "English (Canada)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "English (Canada)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Engels (Canada)"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Английский (Канада)"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "英语 （加拿大）"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Englisch (Kanada)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Engelsk (Canada)"
        }]
      },
      {
        "code" : "en-GB",
        "display" : "English (Great Britain)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "English (Great Britain)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Engels (Groot Brittannië)"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Английский (Великобритания)"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "英语 （英国）"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Englisch (Großbritannien)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Engelsk (Storbritannien)"
        }]
      },
      {
        "code" : "en-IN",
        "display" : "English (India)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "English (India)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Engels (India)"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Английский (Индия)"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "英语 （印度）"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Englisch (Indien)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Engelsk (Indien)"
        }]
      },
      {
        "code" : "en-NZ",
        "display" : "English (New Zeland)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "English (New Zeland)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Engels (Nieuw Zeeland)"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Английский (Новая Зеландия)"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "英语 （新西兰）"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Englisch (Neuseeland)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Engelsk (New Zeeland)"
        }]
      },
      {
        "code" : "en-SG",
        "display" : "English (Singapore)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "English (Singapore)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Engels (Singapore)"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Английский (Сингапур)"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "英语 （新加坡）"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Englisch (Singapur)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Engelsk (Singapore)"
        }]
      },
      {
        "code" : "en-US",
        "display" : "English (United States)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "English (United States)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Engels (Verenigde Staten)"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Английский (США)"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "英语 （美国）"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Englisch (USA)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Engelsk (Amerikansk)"
        }]
      },
      {
        "code" : "es",
        "display" : "Spanish",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Spanish"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Spaans"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Испанский"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "西班牙语"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Spanisch"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Spansk"
        }]
      },
      {
        "code" : "es-AR",
        "display" : "Spanish (Argentina)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Spanish (Argentina)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Spaans (Argentinië)"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Испанский (Аргентина)"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "西班牙语 （阿根廷）"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Spanisch (Argentinien)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Spansk (Argentina)"
        }]
      },
      {
        "code" : "es-ES",
        "display" : "Spanish (Spain)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Spanish (Spain)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Spaans (Spanje)"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Испанский (Испания)"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "西班牙语 （西班牙）"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Spanisch (Spanien)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Spansk (Spanien)"
        }]
      },
      {
        "code" : "es-UY",
        "display" : "Spanish (Uruguay)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Spanish (Uruguay)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Spaans (Uruguay)"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Испанский (Уругвай)"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "西班牙语 （乌拉圭）"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Spanisch (Uruguay)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Spansk (Uruguay)"
        }]
      },
      {
        "code" : "fi",
        "display" : "Finnish",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Finnish"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Fins"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Финский"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "芬兰语"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Finnisch"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Finsk"
        }]
      },
      {
        "code" : "fr",
        "display" : "French",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "French"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Frans"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Французский"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "法语"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Französisch"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Fransk"
        }]
      },
      {
        "code" : "fr-BE",
        "display" : "French (Belgium)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "French (Belgium)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Frans (België)"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Französisch (Belgien)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Finsk (Belgien)"
        }]
      },
      {
        "code" : "fr-CH",
        "display" : "French (Switzerland)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "French (Switzerland)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Frans (Zwitserland)"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Французский (Швейцария)"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "法语 （比利时）"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Französisch (Schweiz)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Fransk (Schweiz)"
        }]
      },
      {
        "code" : "fr-FR",
        "display" : "French (France)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "French (France)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Frans (Frankrijk)"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Французский (Франция)"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "法语 （瑞士）"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Französisch (Frankreich)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Fransk (Frankrig)"
        }]
      },
      {
        "code" : "fy",
        "display" : "Frysian",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Frysian"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Fries"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "弗里士兰语"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Friesisch"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Frisisk"
        }]
      },
      {
        "code" : "fy-NL",
        "display" : "Frysian (Netherlands)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Frysian (Netherlands)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Fries (Nederland)"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "弗里士兰语（荷兰）"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Friesisch (Niederlande)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Frisisk (Holland)"
        }]
      },
      {
        "code" : "hi",
        "display" : "Hindi",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Hindi"
        },
        {
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Hindi"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Hindi"
        }]
      },
      {
        "code" : "hr",
        "display" : "Croatian",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Croatian"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Kroatisch"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Хорватский"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "克罗地亚语"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Kroatisch"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Kroatisk"
        }]
      },
      {
        "code" : "it",
        "display" : "Italian",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Italian"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Italiaans"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Итальянский"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "意大利语"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Italienisch"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Italiensk"
        }]
      },
      {
        "code" : "it-CH",
        "display" : "Italian (Switzerland)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Italian (Switzerland)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Italiaans (Zwitserland)"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Итальянский (Швейцария)"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "意大利语 （瑞士）"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Italienisch (Schweiz)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Italiensk (Schweiz)"
        }]
      },
      {
        "code" : "it-IT",
        "display" : "Italian (Italy)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Italian (Italy)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Italiaans (Italië)"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Итальянский (Италия)"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "意大利语 （意大利）"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Italienisch (Italien)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Italiensk (Italien)"
        }]
      },
      {
        "code" : "ja",
        "display" : "Japanese",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Japanese"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Japans"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Японский"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "日语"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Japanisch"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Japansk"
        }]
      },
      {
        "code" : "ko",
        "display" : "Korean",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Korean"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Koreaans"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Корейский"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "朝鲜语"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Koreanisch"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Koreansk"
        }]
      },
      {
        "code" : "nl",
        "display" : "Dutch",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Dutch"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Nederlands"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Нидерландский"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "荷兰语"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Niederländisch"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Hollandsk"
        }]
      },
      {
        "code" : "nl-BE",
        "display" : "Dutch (Belgium)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Dutch (Belgium)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Nederlands (België)"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "荷兰语 （比利时）"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Niederländisch (Belgien)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Hollandsk (Belgien)"
        }]
      },
      {
        "code" : "nl-NL",
        "display" : "Dutch (Netherlands)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Dutch (Netherlands)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Nederlands (Nederland)"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Нидерландский (Нидерланды)"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "荷兰语 （荷兰）"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Niederländisch (Niederlande)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Hollandsk (Holland)"
        }]
      },
      {
        "code" : "no",
        "display" : "Norwegian",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Norwegian"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Noors"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Норвежский"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "挪威语"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Norwegisch"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Norsk"
        }]
      },
      {
        "code" : "no-NO",
        "display" : "Norwegian (Norway)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Norwegian (Norway)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Noors (Noorwegen)"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Норвежский (Норвегия)"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "挪威语 （挪威）"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Norwegisch (Norwegen)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Norsk (Norge)"
        }]
      },
      {
        "code" : "pa",
        "display" : "Punjabi",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Punjabi"
        },
        {
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Punjabi"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Punjabi"
        }]
      },
      {
        "code" : "pl",
        "display" : "Polish",
        "designation" : [{
          "language" : "pl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Polskie"
        }]
      },
      {
        "code" : "pt",
        "display" : "Portuguese",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Portuguese"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Portugees"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Португальский"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "葡萄牙语"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Portugiesisch"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Portugisisk"
        }]
      },
      {
        "code" : "pt-BR",
        "display" : "Portuguese (Brazil)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Portuguese (Brazil)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Portugees (Brazilië)"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Португальский (Бразилия)"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "葡萄牙语 （巴西）"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Portugiesisch (Brasilien)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Portugisisk (Brasilien)"
        }]
      },
      {
        "code" : "ru",
        "display" : "Russian",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Russian"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Russisch"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Русский"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "俄语"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Russisch"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Russisk"
        }]
      },
      {
        "code" : "ru-RU",
        "display" : "Russian (Russia)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Russian (Russia)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Russisch (Rusland)"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Русский (Россия)"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "俄语 （俄罗斯）"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Russisch (Russland)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Russisk (Rusland)"
        }]
      },
      {
        "code" : "sr",
        "display" : "Serbian",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Serbian"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Servisch"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Сербский"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "塞尔维亚语"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Serbisch"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Serbisk"
        }]
      },
      {
        "code" : "sr-RS",
        "display" : "Serbian (Serbia)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Serbian (Serbia)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Servisch (Servië)"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Сербский (Сербия)"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "塞尔维亚语 （塞尔维亚）"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Serbisch (Serbien)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Serbisk (Serbien)"
        }]
      },
      {
        "code" : "sv",
        "display" : "Swedish",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Swedish"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Zweeds"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Шведский"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "瑞典语"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Schwedisch"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Svensk"
        }]
      },
      {
        "code" : "sv-SE",
        "display" : "Swedish (Sweden)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Swedish (Sweden)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Zweeds (Zweden)"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Шведский (Швеция)"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "瑞典语 （瑞典）"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Schwedisch (Schweden)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Svensk (Sverige)"
        }]
      },
      {
        "code" : "te",
        "display" : "Telegu",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Telegu"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Teloegoe"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Телугу"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "泰卢固语"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Telugu"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Telugu"
        }]
      },
      {
        "code" : "zh",
        "display" : "Chinese",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Chinese"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Chinees"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Kитайский"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "中文"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Chinesisch"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Kinesisk"
        }]
      },
      {
        "code" : "zh-CN",
        "display" : "Chinese (China)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Chinese (China)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Chinees (China)"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Kитайский (Китай)"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "中文 （中国）"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Chinesisch (China)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Kinesisk (Kina)"
        }]
      },
      {
        "code" : "zh-HK",
        "display" : "Chinese (Hong Kong)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Chinese (Hong Kong)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Chinees (Hong Kong)"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Kитайский (Гонконг)"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "中文 （香港特别行政区）"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Chinesisch (Hong Kong)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Kinesisk (Hong Kong)"
        }]
      },
      {
        "code" : "zh-SG",
        "display" : "Chinese (Singapore)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Chinese (Singapore)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Chinees (Singapore)"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Kитайский (Сингапур)"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "中文 （新加坡）"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Chinesisch (Singapur)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Kinesisk (Singapore)"
        }]
      },
      {
        "code" : "zh-TW",
        "display" : "Chinese (Taiwan)",
        "designation" : [{
          "language" : "en",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Chinese (Taiwan)"
        },
        {
          "language" : "nl",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Chinees (Taiwan)"
        },
        {
          "language" : "ru",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Kитайский (Тайвань)"
        },
        {
          "language" : "zh",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "中文 （台湾）"
        },
        {
          "language" : "de",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Chinesisch (Taiwan)"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/designation-usage",
            "code" : "display"
          },
          "value" : "Kinesisk (Taiwan)"
        }]
      }]
    }]
  }
}

```
